export const environment = {
  production: true,
  apiUrl: 'https://autolonix.iukhan.codes/api'
};
